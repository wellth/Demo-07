#include <stdio.h>
#include "qrsdet.h"

extern int QRSDet (int,int);
extern int RRMean,RRCount,RRLastVal;

int HR;

int heartrate()
{
FILE *fp;
int data,qrsdelay;

        QRSDet(0,1);

        fp = fopen("../data/SecDump_2", "r");

        if ( fp == NULL)
        {
                printf(" ECG Dump File open unsuccessful \n");
                return (0);
        }
	while (!feof(fp))
        {
                fscanf(fp,"%d",&data);
                qrsdelay = QRSDet(data,0);

        }
        // Take the last RR Interval for HR calculation
        HR = ( (60 * 1000 * (RRCount - 1)) / ((RRMean - RRLastVal) * MS_PER_SAMPLE));
        printf( "Heart Rate - %d RR Interval - %d\n", HR,(RRMean - RRLastVal) / (RRCount - 1));
	return(1);
}
